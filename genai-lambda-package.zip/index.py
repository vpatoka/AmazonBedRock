import os
import json
import boto3
from botocore.exceptions import ClientError

def answer_assembly(event, intent, msg):
  return {
    "messages": [
     {
       "content": "From Titan: " + msg,
       "contentType": "PlainText"
     }
    ],
    "sessionState": {
      "dialogAction": {
        "type": "ElicitIntent"
      }
    },
    "intent": {
      "confirmationState": "Confirmed",
      "name": intent,
      "state": "Fulfilled"
    }
  }

def lambda_handler(event, context):
  print(event)
  intent_name = event['sessionState']['intent']['name']
  prompt = event['inputTranscript']
  client = boto3.client(
    service_name="bedrock-runtime",
    region_name="us-west-2"
  )

  body = json.dumps({
    "inputText": prompt,
    "textGenerationConfig": {
      "maxTokenCount": 512,
      "stopSequences": [],
      "temperature": 0,
      "topP": 0.9
    }
  })

  modeId='amazon.titan-text-express-v1'

  response = client.invoke_model(
    body=body,
    modelId=modeId,
    accept="application/json",
    contentType="application/json"
  )

  response_body = json.loads(response.get('body').read())
  outputText = response_body.get('results')[0].get('outputText')

  text = outputText[outputText.index('\n')+1:]
  answer = text.strip()

  payload = answer_assembly(event, intent_name, answer)
  print(payload)
  return(payload)

